def hello():
    print("I am alive!")
