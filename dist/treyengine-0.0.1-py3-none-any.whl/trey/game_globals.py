RENDERER = None
# add ACTIVE_SCENE to globals
CUREENT_SCENE = None
