from trey import test, colors, game_globals, graphics, image, keyboard, maths, scene, test, window
